# This is a test command

def main():
	number = int(input('Enter a number (this is a test package!):\n'))
	print(f'{number} squares in {number**2}')


if __name__ == '__main__':
	main()
