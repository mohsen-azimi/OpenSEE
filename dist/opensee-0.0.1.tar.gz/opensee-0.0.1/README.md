# OpenSEE
An Open-source Python Package for Structural & Earthquake Engineering

## Installation
```pip install opensee```

## How to use it?
Open terminal and type ```opensee```

```under developement!```

## License

© 2021 Mohsen Azimi

This repository is licensed under the MIT license. See LICENSE for details.