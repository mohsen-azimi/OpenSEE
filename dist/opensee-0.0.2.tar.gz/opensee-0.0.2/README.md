# OpenSEE
An Open-source Python Package for Structural & Earthquake Engineering.

## Installation
```pip install opensee```

## How to use it?
Open terminal and type opensee.

```Under development!```

## License

© 2021 Mohsen Azimi, Armin Dadras

This repository is licensed under the MIT license. See LICENSE for details.
